-- This query should return details of flights along with the plane type.
SELECT * FROM Flight_Details;

-- This query should return the booking history of customers.
SELECT * FROM Customer_Booking_History;

-- This query should return the passenger information for each receipt.
SELECT * FROM Passenger_Details;

select * from plane;

select * from location;



