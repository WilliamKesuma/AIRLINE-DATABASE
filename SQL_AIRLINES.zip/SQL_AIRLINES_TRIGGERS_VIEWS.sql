/*==============================================================*/
/* TRIGGER			                                            */
/*==============================================================*/
-- Trigger to ensure that the ECONOMY_AVAILABILITY and BUSINESS_AVAILABILITY fields in the FLIGHT_INFO table are not overbooked:
DELIMITER //
CREATE TRIGGER check_economy_seats BEFORE INSERT ON RECEIPT
FOR EACH ROW
BEGIN
    IF NEW.FLIGHT_CLASS = 'Economy' THEN
        IF (SELECT ECONOMY_AVAILABILITY FROM FLIGHT_INFO WHERE FLIGHT_ID = NEW.FLIGHT_ID) < NEW.TOTAL_SEATS THEN
            SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'Not enough economy seats available';
        END IF;
        
        UPDATE FLIGHT_INFO
        SET ECONOMY_AVAILABILITY = ECONOMY_AVAILABILITY - NEW.TOTAL_SEATS
        WHERE FLIGHT_ID = NEW.FLIGHT_ID;
    END IF;
END//

CREATE TRIGGER check_business_seats BEFORE INSERT ON RECEIPT
FOR EACH ROW
BEGIN
    IF NEW.FLIGHT_CLASS = 'Business' THEN
        IF (SELECT BUSINESS_AVAILABILITY FROM FLIGHT_INFO WHERE FLIGHT_ID = NEW.FLIGHT_ID) < NEW.TOTAL_SEATS THEN
            SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'Not enough business seats available';
        END IF;

        UPDATE FLIGHT_INFO
        SET BUSINESS_AVAILABILITY = BUSINESS_AVAILABILITY - NEW.TOTAL_SEATS
        WHERE FLIGHT_ID = NEW.FLIGHT_ID;
    END IF;
END//
DELIMITER ;

-- Trigger to ensure that PHONE_NUM in the CUSTOMER table contains only digits:
DELIMITER //
CREATE TRIGGER validate_phone_num BEFORE INSERT ON CUSTOMER
FOR EACH ROW
BEGIN
    IF NEW.PHONE_NUM REGEXP '^[0-9]+$' = 0 THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Phone number must contain only digits';
    END IF;
END//
DELIMITER ;

/*==============================================================*/
/* VIEWS               			                                */
/*==============================================================*/

-- View to display flight details along with plane type:
CREATE VIEW Flight_Details AS
SELECT 
    F.FLIGHT_ID,
    F.DATE,
    F.DEPARTURE_TIME,
    F.ARRIVAL_TIME,
    F.DEPARTURE_CITY,
    F.ARRIVAL_CITY,
    F.ECONOMY_SEATS,
    F.BUSINESS_SEATS,
    F.ECONOMY_AVAILABILITY,
    F.BUSINESS_AVAILABILITY,
    F.ECONOMY_PRICE,
    F.BUSINESS_PRICE,
    P.PLANE_TYPE
FROM 
    FLIGHT_INFO F
JOIN 
    PLANE P ON F.PLANE_ID = P.PLANE_ID;
    
-- View to display customer booking history:
    CREATE VIEW Customer_Booking_History AS
SELECT 
    C.ID_CUSTOMER,
    C.PS_FULL_NAME,
    C.EMAIL,
    R.RECEIPT_ID,
    R.FLIGHT_ID,
    R.DATE AS BOOKING_DATE,
    R.FLIGHT_CLASS,
    R.TOTAL_PRICE,
    R.TOTAL_SEATS
FROM 
    CUSTOMER C
JOIN 
    RECEIPT R ON C.ID_CUSTOMER = R.ID_CUSTOMER;
    
-- View to display passenger information for each receipt:
CREATE VIEW Passenger_Details AS
SELECT 
    P.RECEIPT_ID,
    P.PASSENGER_ID,
    P.PS_TITLE,
    P.PS_FULL_NAME,
    P.PS_DOB
FROM 
    PASSENGER_INFO P;


